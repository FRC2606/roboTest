
import ripshell
ripshell.RIPServer( ripshell.config )
