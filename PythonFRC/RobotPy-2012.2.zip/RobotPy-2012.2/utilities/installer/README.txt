
This installer can be used to install RobotPy, or other python code
to the robot. 

install.py is the RobotPy installer; it will install the files
    in ./robot to the root directory of the robot

team_upload.py is a sample installer to show how to use the
    RobotCodeInstaller class in install.py. Place this file in the
    same directory as the code for your team, and run this to copy all
    code in the current directory to /py . You need to modify the script
    to specify which team number you are using. 

Questions or comments? Contact: 
    
Dustin Spicuzza, Team 2423
dustin@virtualroadside.com

